<?php
/**
 * Title: index
 * Slug: lesio/index
 * Inserter: no
 */
?>
<!-- wp:paragraph -->
<p><?php esc_html_e('ddadwd', 'lesio');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:post-content /-->